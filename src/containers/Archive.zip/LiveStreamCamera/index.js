import {
  Text,
  View,
  PermissionsAndroid,
  Dimensions,
  TouchableOpacity,
  Platform,
  Image,
} from 'react-native';
import React, {Component} from 'react';
import {NodeCameraView} from 'react-native-nodemediaclient';
import {Colors, Fonts, NavService} from '../../config';
import Icons from '../../assets/Icons';
import {updateRoomStatus} from '../../redux/APIs';

const {width, height} = Dimensions.get('window');

export class LiveStreamCamera extends Component {
  constructor(props) {
    super(props);
    this.livestreamRef = React.createRef();
  }
  state = {
    isStreaming: false,
    min: '00',
    sec: '00',
    key: false,
  };

  requestPermissions = async () => {
    const permissionCamera = await requestCameraPermission();
    const permissionAudio = await requestAudioPermission();
    if (permissionCamera && permissionAudio) {
      this.setState({key: !this.state.key});
    }
  };

  timer = () => {
    let totalSeconds = 0;
    let newSec = 0;
    let newMin = 0;

    this.timerInterval = setInterval(() => {
      ++totalSeconds;
      newSec = pad(totalSeconds % 60);
      newMin = pad(parseInt(totalSeconds / 60));
      this.setState({min: newMin, sec: newSec});
    }, 1000);

    function pad(val) {
      let valString = val + '';
      if (valString.length < 2) {
        return '0' + valString;
      } else {
        return valString;
      }
    }
  };

  onStreamStop = async () => {
    this.livestreamRef.current.stop();
    await updateRoomStatus(this.props.route.params?.id, 'offline');
    this.setState({isStreaming: false});
    clearInterval(this.timerInterval);
  };
  onStreamStart = async () => {
    this.livestreamRef.current.start();
    await updateRoomStatus(this.props.route.params?.id, 'online');
    this.setState({isStreaming: true});
    this.timer();
  };

  async componentDidMount() {
    Platform.OS === 'android' && (await this.requestPermissions());
  }

  componentWillUnmount() {
    clearInterval(this.timerInterval);
    this.livestreamRef.current.stop();
  }

  render() {
    const {isStreaming, min, sec} = this.state;
    const {stream} = this.props.route.params;
    return (
      <View style={{flex: 1, backgroundColor: 'black'}}>
        <NodeCameraView
          key={this.state.key}
          style={{
            width,
            height,
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'black',
          }}
          ref={this.livestreamRef}
          outputUrl={
            'rtmps://global-live.mux.com:443/app/' + stream?.stream_key
          }
          camera={{cameraId: 1, cameraFrontMirror: true}}
          audio={{bitrate: 32000, profile: 1, samplerate: 44100}}
          video={{
            preset: 12,
            bitrate: 400000,
            profile: 1,
            fps: 15,
            videoFrontMirror: false,
          }}
          autopreview={true}
        />
        <TouchableOpacity
          onPress={() => {
            if (isStreaming) {
              this.onStreamStop();
            }
            NavService.goBack();
          }}
          style={{
            position: 'absolute',
            top: 60,
            left: 20,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            source={Icons.back}
            style={{width: 30, height: 30, tintColor: Colors.white}}
          />
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => {
            this.livestreamRef.current.switchCamera();
          }}
          style={{
            position: 'absolute',
            bottom: 65,
            right: 30,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            source={Icons.flip}
            style={{width: 40, height: 40, tintColor: Colors.white}}
          />
        </TouchableOpacity>
        {isStreaming && (
          <View
            style={{
              position: 'absolute',
              top: 60,
              right: 20,
              alignItems: 'center',
              justifyContent: 'center',
              padding: 5,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: Colors.white,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View
              style={{
                height: 15,
                width: 15,
                borderRadius: 15,
                backgroundColor: Colors.red,
              }}
            />
            <Text
              style={{
                color: Colors.white,
                fontFamily: Fonts.bold,
                fontSize: 16,
                marginLeft: 5,
              }}>
              {min}:{sec}
            </Text>
          </View>
        )}
        <TouchableOpacity
          onPress={() => {
            if (isStreaming) {
              this.onStreamStop();
            } else {
              this.onStreamStart();
            }
          }}
          style={{
            width: 75,
            height: 75,
            borderRadius: 75 / 2,
            borderWidth: 2,
            borderColor: Colors.white,
            position: 'absolute',
            alignSelf: 'center',
            bottom: 50,

            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {isStreaming ? (
            <View
              style={{
                width: 30,
                height: 30,
                backgroundColor: Colors.red,
                borderRadius: 10,
              }}
            />
          ) : (
            <View
              style={{
                width: 55,
                height: 55,
                backgroundColor: Colors.white,
                borderRadius: 55 / 2,
              }}
            />
          )}
        </TouchableOpacity>
      </View>
    );
  }
}

export default LiveStreamCamera;

const requestCameraPermission = async () => {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: 'Camera Permission Required',
        message: 'Fly - the Original Sleep needs access to your camera ',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'Cancel',
        buttonPositive: 'OK',
      },
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log('You can use the camera');
      return true;
    } else {
      console.log('Camera permission denied');
      return false;
    }
  } catch (err) {
    console.warn(err);
  }
};

const requestAudioPermission = async () => {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
      {
        title: 'Microphone Permission Required',
        message: 'Fly - the Original Sleep needs access to your microphone',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'Cancel',
        buttonPositive: 'OK',
      },
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log('You can use the Microphone');
      return true;
    } else {
      console.log('Microphone permission denied');
      return false;
    }
  } catch (err) {
    console.warn(err);
  }
};
