import {
  Text,
  View,
  Dimensions,
  TouchableOpacity,
  Platform,
  Image,
} from 'react-native';
import React, {Component} from 'react';
import {NodePlayerView} from 'react-native-nodemediaclient';
import {Colors, Fonts, NavService} from '../../config';
import Icons from '../../assets/Icons';
import {loaderStart, loaderStop} from '../../redux/actions';
import Toast from 'react-native-toast-message';

const {width, height} = Dimensions.get('window');

export class LiveStreamPlayer extends Component {
  constructor(props) {
    super(props);
    this.livestreamRef = React.createRef();
  }
  state = {
    isStreaming: false,
    min: '00',
    sec: '00',
    reconnectAttempts: 0,
  };

  timer = () => {
    let totalSeconds = 0;
    let newSec = 0;
    let newMin = 0;

    this.timerInterval = setInterval(() => {
      ++totalSeconds;
      newSec = pad(totalSeconds % 60);
      newMin = pad(parseInt(totalSeconds / 60));
      this.setState({min: newMin, sec: newSec});
    }, 1000);

    function pad(val) {
      let valString = val + '';
      if (valString.length < 2) {
        return '0' + valString;
      } else {
        return valString;
      }
    }
  };

  render() {
    const {isStreaming, min, sec} = this.state;
    const {stream} = this.props.route.params;
    console.log('stream', stream);
    return (
      <View style={{flex: 1, backgroundColor: 'black'}}>
        <NodePlayerView
          style={{
            width,
            height,
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'black',
          }}
          ref={this.livestreamRef}
          inputUrl={
            'https://stream.mux.com/' + stream?.playback_ids[0]?.id + '.m3u8'
          }
          scaleMode={'ScaleAspectFill'}
          bufferTime={300}
          maxBufferTime={1000}
          autoplay={true}
          onStatus={event => {
            console.log('onStatus', event);
            // alert(JSON.stringify(event));
            if (event == 1003) {
              if (this.state.reconnectAttempts < 5) {
                this.setState({
                  reconnectAttempts: this.state.reconnectAttempts + 1,
                });
                loaderStart();
              } else {
                loaderStop();
                Toast.show({
                  text1: 'Unable to connect to stream',
                  textStyle: {textAlign: 'center'},
                  type: 'error',
                  visibilityTime: 5000,
                });
                NavService.goBack();
              }
            } else if (event == 1000) {
              loaderStart();
            } else if (event == 1102) {
              this.setState({reconnectAttempts: 0});
              loaderStop();
            }
          }}
        />
        <TouchableOpacity
          onPress={() => {
            NavService.goBack();
          }}
          style={{
            position: 'absolute',
            top: 60,
            left: 20,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            source={Icons.back}
            style={{width: 30, height: 30, tintColor: Colors.white}}
          />
        </TouchableOpacity>
        {/* {isStreaming && (
          <View
            style={{
              position: 'absolute',
              top: 60,
              right: 20,
              alignItems: 'center',
              justifyContent: 'center',
              padding: 5,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: Colors.white,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View
              style={{
                height: 15,
                width: 15,
                borderRadius: 15,
                backgroundColor: Colors.red,
              }}
            />
            <Text
              style={{
                color: Colors.white,
                fontFamily: Fonts.bold,
                fontSize: 16,
                marginLeft: 5,
              }}>
              {min}:{sec}
            </Text>
          </View>
        )} */}
      </View>
    );
  }
}

export default LiveStreamPlayer;
